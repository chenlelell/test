package test;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zccp on 2017/6/19.
 */
public class BlockChain {

    public List<String> publickey= new ArrayList<String>();
    private List<String> privatekey= new ArrayList<String>();
    private List<User> usermessage= new ArrayList<User>();
    //存放公私钥
    public String generateKey(String PrivKey,String PubKey){
        System.out.println(PrivKey);
       privatekey.add(PrivKey);
       publickey.add(PubKey);
       blockChain(publickey.get(0));
       return  sign("自定义的内容");
    }
    //公钥发送到区块链
    public void blockChain(String info){
        User user=new User();
        user.setInfo(info);
        usermessage.add(user);
    }
   //共识方法确认交易
    public String consensus(String s){
    //假设成功
     if (true){
         System.out.println("模拟成功");
         System.out.println("您的公钥为："+publickey.get(0));
         System.out.println("您的私钥为："+privatekey.get(0));
         System.out.println("您的交易为："+s);
     }
     else {
         System.out.println("模拟失败");
     }
     return "您的公钥为："+publickey.get(0)+"您的私钥为："+privatekey.get(0)+"您的交易为："+s;
    }

    //用自己的私钥对需要发送到区块链的交易做签名
    public  String sign(String info){
        //模拟签名
        String s=info;
        // 将签名后的数据发送给区块链
        return  consensus(s);

    }
}
