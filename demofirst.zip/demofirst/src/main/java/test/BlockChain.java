package test;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by zccp on 2017/6/19.
 */
@RestController
@RequestMapping("/users")
public class BlockChain {
    public List<String> publickey;
    private List<String> privatekey;
    private List<User> usermessage;
    Register register=new Register();

    /**
     * 存放公私钥
     * @param PrivKey
     * @param PubKey
     * @return
     */
    public String generateKey(String PrivKey,String PubKey){
       privatekey.add(PrivKey);
       publickey.add(PubKey);
       blockChain(publickey.get(0));
       return  register.sign("自定义的内容");
    }
    /**
     *公钥发送到区块链
     */
    public void blockChain(String info){
        User user=new User();
        user.setInfo(info);
        usermessage.add(user);
    }

    /**
     * 共识方法确认交易
     * @param s
     */
    public String consensus(String s){
        /**
         * 假设成功
         */
     if (true){
         System.out.println("模拟成功");
         System.out.println("您的公钥为："+publickey.get(0));
         System.out.println("您的私钥为："+privatekey.get(0));
         System.out.println("您的交易为："+s);
     }
     else {
         System.out.println("模拟失败");
     }
     return "您的公钥为："+publickey.get(0)+"您的私钥为："+privatekey.get(0)+"您的交易为："+s;
    }
}
