package test;

import org.ethereum.crypto.ECKey;
import org.ethereum.crypto.ECKey.ECDSASignature;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by zccp on 2017/6/19.
 */
public class Register {
    //暂时无用
    BlockChain blockChain=new BlockChain();
    public  String register(){
        ECKey ecKey = new ECKey();
       String PubKey= (ecKey.getPubKey()).toString();//公钥
        ecKey.getPrivKey();//私钥
        ecKey.getAddress();//公钥地址
        ECDSASignature signature = ecKey.sign("".getBytes());//签名
        String signAfter=signature.toBase64();//签名后的数据
        System.out.println("您的公钥是"+PubKey);
        //blockChain.generateKey(s);
        return PubKey;
    }
 }