package test;

import org.ethereum.crypto.ECKey;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.ethereum.crypto.ECKey.ECDSASignature;
/**
 * Created by zccp on 2017/6/19.
 */
@RestController
@RequestMapping("/test")
public class Test {
    BlockChain blockChain=new BlockChain();
    @RequestMapping("/a")
    public String register(){
      /**
        ECKey ecKey = new ECKey();
        String PubKey= (ecKey.getPubKey()).toString();//公钥
        ecKey.getPrivKey();//私钥
        ecKey.getAddress();//公钥地址
        ECDSASignature signature = ecKey.sign("".getBytes());//签名
        String signAfter=signature.toBase64();//签名后的数据
        System.out.println("您的公钥是"+PubKey);
        */
        /**
         * 生成私钥
         */
        String PrivKey=String.valueOf(Math.random()*100);
        /**
         * 生成公钥
         */
        String PubKey=String.valueOf(Math.random()*100);
        return  blockChain.generateKey(PrivKey,PubKey);
    }

}
