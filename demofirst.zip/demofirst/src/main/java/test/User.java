package test;

/**
 * Created by zccp on 2017/6/19.
 */
public class User {
    private String info;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
