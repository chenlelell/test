package test;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * Created by zccp on 2017/6/19.
 */

 public class ForTestNG {

     BlockChain blockChain=new BlockChain();

 public String first(){
    System.out.println(2121);
    return "fafd";
}
 public void forTestNg(){
        String s ="11";
        blockChain.consensus(s);
    }
}
